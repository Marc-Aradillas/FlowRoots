import tempfile
import unittest
from pathlib import Path

from chatbot.core.actions import ActionContext, ActionRouter, parse_json_actions
from chatbot.core.database import Database
from chatbot.core.memory import MemoryStore
from chatbot.core.tasks import TaskStore


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "test.db")
        self.mem = MemoryStore(self.db)
        self.tasks = TaskStore(self.db)

    def tearDown(self):
        self.tmp.cleanup()

    def test_persistent_message_history(self):
        self.mem.add_message(123, "user", "hello", guild_id=1, author_name="Rishi")
        self.mem.add_message(123, "model", "yo", guild_id=1, author_name="FlowBot")
        history = self.mem.recent_messages(123)
        self.assertEqual([h["role"] for h in history], ["user", "model"])

    def test_memory_search(self):
        self.mem.remember("Wonder owns the FlowRoots website", guild_id=1, channel_id=2, category="project")
        rows = self.mem.search("Who owns website?", guild_id=1, channel_id=2)
        self.assertEqual(rows[0]["category"], "project")

    def test_task_lifecycle(self):
        task_id = self.tasks.create("Book venue", guild_id=1, channel_id=2, owner="Rift", priority="high")
        self.assertEqual(self.tasks.get(task_id)["status"], "open")
        self.assertTrue(self.tasks.update_status(task_id, "done"))
        self.assertEqual(self.tasks.get(task_id)["status"], "done")

    def test_action_router(self):
        router = ActionRouter(self.mem, self.tasks)
        results = router.execute([
            {"type": "remember", "content": "September jam is approved", "category": "decision"},
            {"type": "create_task", "title": "Post flyer", "owner": "Marc", "priority": "normal"},
        ], ActionContext(guild_id=1, channel_id=2, author_name="Rishi"))
        self.assertEqual(len(results), 2)
        self.assertEqual(len(self.tasks.list(1, 2)), 1)

    def test_json_parser(self):
        parsed = parse_json_actions('```json\n{"actions":[{"type":"remember","content":"x"}]}\n```')
        self.assertEqual(parsed[0]["type"], "remember")


if __name__ == "__main__":
    unittest.main()
