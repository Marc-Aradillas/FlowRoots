"""GitHub integration boundary.

FlowBot's core does not require GitHub. Add read/write methods here when GITHUB_TOKEN and
GITHUB_REPOSITORY are configured, keeping API side effects isolated from Discord handlers.
"""
from __future__ import annotations

import os


class GitHubService:
    def __init__(self):
        self.token = os.getenv("GITHUB_TOKEN")
        self.repository = os.getenv("GITHUB_REPOSITORY")

    @property
    def configured(self) -> bool:
        return bool(self.token and self.repository)
