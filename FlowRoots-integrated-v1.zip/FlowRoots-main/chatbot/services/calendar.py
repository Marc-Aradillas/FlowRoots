"""Calendar integration boundary.

A concrete Google Calendar adapter can be connected here without coupling calendar credentials to
FlowBot's Discord process. Until configured, FlowBot can still persist proposed dates as tasks.
"""
from __future__ import annotations

import os


class CalendarService:
    @property
    def configured(self) -> bool:
        return bool(os.getenv("GOOGLE_CALENDAR_CREDENTIALS"))
