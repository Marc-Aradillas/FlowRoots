"""Document/Drive integration boundary for future FlowRoots files and meeting notes."""
from __future__ import annotations

import os


class DocumentService:
    @property
    def configured(self) -> bool:
        return bool(os.getenv("GOOGLE_DRIVE_CREDENTIALS"))
