"""Core FlowBot persistence and orchestration utilities."""
