from __future__ import annotations

import json
import re
from dataclasses import dataclass

from .memory import MemoryStore
from .tasks import TaskStore


@dataclass
class ActionContext:
    guild_id: str | int | None
    channel_id: str | int | None
    author_name: str | None


class ActionRouter:
    """Executes safe local actions planned by the model.

    External write-capable integrations intentionally require explicit service adapters and are not
    silently executed. This keeps FlowBot useful without giving the LLM unrestricted side effects.
    """

    ALLOWED = {"remember", "create_task", "complete_task"}

    def __init__(self, memories: MemoryStore, tasks: TaskStore):
        self.memories = memories
        self.tasks = tasks

    def execute(self, actions: list[dict], ctx: ActionContext) -> list[str]:
        results: list[str] = []
        for action in actions[:8]:
            kind = str(action.get("type", "")).strip()
            if kind not in self.ALLOWED:
                continue
            try:
                if kind == "remember":
                    content = str(action.get("content", "")).strip()
                    if not content:
                        continue
                    memory_id = self.memories.remember(
                        content,
                        guild_id=ctx.guild_id,
                        channel_id=ctx.channel_id,
                        category=str(action.get("category", "general"))[:40],
                        source_author=ctx.author_name,
                    )
                    results.append(f"Saved memory #{memory_id}")
                elif kind == "create_task":
                    title = str(action.get("title", "")).strip()
                    if not title:
                        continue
                    task_id = self.tasks.create(
                        title=title,
                        description=str(action.get("description", "")),
                        owner=_clean_optional(action.get("owner")),
                        due_at=_clean_optional(action.get("due_at")),
                        priority=str(action.get("priority", "normal")),
                        created_by=ctx.author_name,
                        guild_id=ctx.guild_id,
                        channel_id=ctx.channel_id,
                    )
                    results.append(f"Created task #{task_id}: {title}")
                elif kind == "complete_task":
                    task_id = int(action.get("task_id"))
                    if self.tasks.update_status(task_id, "done"):
                        results.append(f"Completed task #{task_id}")
            except (ValueError, TypeError):
                continue
        return results


def parse_json_actions(text: str) -> list[dict]:
    if not text:
        return []
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, flags=re.S)
        if not match:
            return []
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError:
            return []
    if isinstance(data, dict):
        data = data.get("actions", [])
    return [x for x in data if isinstance(x, dict)] if isinstance(data, list) else []


def _clean_optional(value):
    if value in (None, "", "null", "None"):
        return None
    return str(value)
