from __future__ import annotations

from .database import Database

VALID_STATUSES = {"open", "in_progress", "blocked", "done", "cancelled"}
VALID_PRIORITIES = {"low", "normal", "high", "urgent"}


class TaskStore:
    def __init__(self, db: Database):
        self.db = db

    def create(self, title: str, guild_id=None, channel_id=None, description="", owner=None,
               due_at=None, priority="normal", created_by=None) -> int:
        priority = priority if priority in VALID_PRIORITIES else "normal"
        now = self.db.now()
        with self.db.connect() as conn:
            cur = conn.execute(
                """INSERT INTO tasks(guild_id,channel_id,title,description,owner,due_at,status,priority,created_by,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,'open',?,?,?,?)""",
                (_s(guild_id), _s(channel_id), title.strip(), description.strip(), owner, due_at,
                 priority, created_by, now, now),
            )
            return int(cur.lastrowid)

    def list(self, guild_id=None, channel_id=None, include_done=False, owner=None, limit=25) -> list[dict]:
        clauses, params = [], []
        if guild_id is not None:
            clauses.append("(guild_id=? OR guild_id IS NULL)")
            params.append(str(guild_id))
        if channel_id is not None:
            clauses.append("(channel_id=? OR channel_id IS NULL)")
            params.append(str(channel_id))
        if not include_done:
            clauses.append("status NOT IN ('done','cancelled')")
        if owner:
            clauses.append("LOWER(owner) LIKE ?")
            params.append(f"%{owner.lower()}%")
        where = " AND ".join(clauses) if clauses else "1=1"
        params.append(limit)
        with self.db.connect() as conn:
            rows = conn.execute(
                f"""SELECT id,title,description,owner,due_at,status,priority,created_by,created_at,updated_at
                    FROM tasks WHERE {where}
                    ORDER BY CASE priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,
                             COALESCE(due_at,'9999-12-31'), id DESC LIMIT ?""",
                params,
            ).fetchall()
        return [dict(r) for r in rows]

    def update_status(self, task_id: int, status: str) -> bool:
        if status not in VALID_STATUSES:
            raise ValueError(f"Invalid task status: {status}")
        with self.db.connect() as conn:
            cur = conn.execute(
                "UPDATE tasks SET status=?, updated_at=? WHERE id=?",
                (status, self.db.now(), task_id),
            )
            return cur.rowcount > 0

    def get(self, task_id: int) -> dict | None:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        return dict(row) if row else None


def _s(value):
    return None if value is None else str(value)
