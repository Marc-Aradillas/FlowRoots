from __future__ import annotations

from typing import Iterable

from .database import Database


class MemoryStore:
    def __init__(self, db: Database):
        self.db = db

    def add_message(self, channel_id, role, content, guild_id=None, author_id=None, author_name=None):
        with self.db.connect() as conn:
            conn.execute(
                """INSERT INTO messages(channel_id,guild_id,author_id,author_name,role,content,created_at)
                   VALUES(?,?,?,?,?,?,?)""",
                (str(channel_id), _s(guild_id), _s(author_id), author_name, role, content, self.db.now()),
            )

    def recent_messages(self, channel_id, limit: int = 12) -> list[dict]:
        with self.db.connect() as conn:
            rows = conn.execute(
                """SELECT role, content FROM messages WHERE channel_id=?
                   ORDER BY id DESC LIMIT ?""",
                (str(channel_id), limit),
            ).fetchall()
        rows = list(reversed(rows))
        return [{"role": row["role"], "parts": [{"text": row["content"]}]} for row in rows]

    def clear_channel_messages(self, channel_id):
        with self.db.connect() as conn:
            conn.execute("DELETE FROM messages WHERE channel_id=?", (str(channel_id),))

    def remember(self, content: str, guild_id=None, channel_id=None, category="general", source_author=None) -> int:
        now = self.db.now()
        with self.db.connect() as conn:
            cur = conn.execute(
                """INSERT INTO memories(guild_id,channel_id,category,content,source_author,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?)""",
                (_s(guild_id), _s(channel_id), category, content.strip(), source_author, now, now),
            )
            return int(cur.lastrowid)

    def search(self, query: str, guild_id=None, channel_id=None, limit: int = 8) -> list[dict]:
        terms = [t.strip(".,!?;:()[]{}\"'").lower() for t in query.split() if len(t.strip(".,!?;:()[]{}\"'")) >= 3]
        terms = terms[:8]
        clauses = []
        params: list[object] = []
        if guild_id is not None:
            clauses.append("(guild_id=? OR guild_id IS NULL)")
            params.append(str(guild_id))
        if channel_id is not None:
            clauses.append("(channel_id=? OR channel_id IS NULL)")
            params.append(str(channel_id))
        if terms:
            clauses.append("(" + " OR ".join("LOWER(content) LIKE ?" for _ in terms) + ")")
            params.extend([f"%{t}%" for t in terms])
        where = " AND ".join(clauses) if clauses else "1=1"
        params.append(limit)
        with self.db.connect() as conn:
            rows = conn.execute(
                f"""SELECT id,category,content,source_author,created_at FROM memories
                    WHERE {where} ORDER BY updated_at DESC LIMIT ?""",
                params,
            ).fetchall()
        return [dict(r) for r in rows]

    def list_recent(self, guild_id=None, channel_id=None, limit: int = 10) -> list[dict]:
        clauses, params = [], []
        if guild_id is not None:
            clauses.append("(guild_id=? OR guild_id IS NULL)")
            params.append(str(guild_id))
        if channel_id is not None:
            clauses.append("(channel_id=? OR channel_id IS NULL)")
            params.append(str(channel_id))
        where = " AND ".join(clauses) if clauses else "1=1"
        params.append(limit)
        with self.db.connect() as conn:
            rows = conn.execute(
                f"SELECT id,category,content,source_author,created_at FROM memories WHERE {where} ORDER BY id DESC LIMIT ?",
                params,
            ).fetchall()
        return [dict(r) for r in rows]


def _s(value):
    return None if value is None else str(value)
