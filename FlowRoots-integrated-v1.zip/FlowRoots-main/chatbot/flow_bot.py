from __future__ import annotations

import asyncio
import os
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

try:
    from chatbot.core.actions import ActionContext, ActionRouter
    from chatbot.core.database import Database
    from chatbot.core.memory import MemoryStore
    from chatbot.core.tasks import TaskStore
    from chatbot.router import plan_actions, query_llm
except ModuleNotFoundError:  # Allows: python chatbot/flow_bot.py
    from core.actions import ActionContext, ActionRouter
    from core.database import Database
    from core.memory import MemoryStore
    from core.tasks import TaskStore
    from router import plan_actions, query_llm

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

_db = Database()
memories = MemoryStore(_db)
tasks = TaskStore(_db)
actions = ActionRouter(memories, tasks)


def chunk_message(text: str, max_length: int = 1900) -> list[str]:
    chunks: list[str] = []
    text = text or ""
    while len(text) > max_length:
        split_idx = text.rfind("\n", 0, max_length)
        if split_idx == -1:
            split_idx = text.rfind(" ", 0, max_length)
        if split_idx == -1:
            split_idx = max_length
        chunks.append(text[:split_idx])
        text = text[split_idx:].lstrip()
    if text:
        chunks.append(text)
    return chunks


async def get_channel_context(channel, limit=40) -> str:
    """Fetch recent Discord text for explicit /summarize requests."""
    messages = []
    async for msg in channel.history(limit=limit, oldest_first=False):
        if not msg.author.bot and msg.content:
            messages.append(f"{msg.author.display_name}: {msg.content}")
    messages.reverse()
    return "\n".join(messages)


def format_operational_context(prompt: str, guild_id, channel_id) -> str:
    relevant = memories.search(prompt, guild_id=guild_id, channel_id=channel_id, limit=8)
    open_tasks = tasks.list(guild_id=guild_id, channel_id=channel_id, include_done=False, limit=12)
    sections = []
    if relevant:
        sections.append("Relevant durable memories:\n" + "\n".join(
            f"- [memory #{m['id']}/{m['category']}] {m['content']}" for m in relevant
        ))
    if open_tasks:
        sections.append("Open tasks:\n" + "\n".join(
            f"- [task #{t['id']}] {t['title']} | owner={t['owner'] or 'unassigned'} | "
            f"due={t['due_at'] or 'none'} | status={t['status']} | priority={t['priority']}"
            for t in open_tasks
        ))
    return "\n\n".join(sections)


async def process_llm_prompt(channel_id, prompt: str, send_func, channel_obj=None,
                             provider: str = "gemini-fast", guild_id=None,
                             author_id=None, author_name=None):
    """Persist context, run safe local actions, then answer with retrieved FlowRoots context."""
    memories.add_message(channel_id, "user", prompt, guild_id, author_id, author_name)

    recent = memories.recent_messages(channel_id, limit=12)
    known_tasks = tasks.list(guild_id=guild_id, channel_id=channel_id, include_done=True, limit=20)
    loop = asyncio.get_running_loop()

    planned = await loop.run_in_executor(None, plan_actions, prompt, known_tasks)
    action_results = actions.execute(
        planned,
        ActionContext(guild_id=guild_id, channel_id=channel_id, author_name=author_name),
    )

    context = format_operational_context(prompt, guild_id, channel_id)
    if action_results:
        context += "\n\nActions completed in this turn:\n" + "\n".join(f"- {r}" for r in action_results)

    reply = await loop.run_in_executor(None, query_llm, provider, recent, context)
    memories.add_message(channel_id, "model", reply, guild_id, getattr(bot.user, "id", None), "FlowBot")

    chunks = chunk_message(reply)
    if chunks:
        await send_func(chunks[0])
        if len(chunks) > 1 and channel_obj:
            for chunk in chunks[1:]:
                await channel_obj.send(chunk)


@bot.event
async def on_ready():
    print(f"⚡ FlowBot active as {bot.user} | DB: {_db.path}")


@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if bot.user and bot.user.mentioned_in(message):
        clean_prompt = message.content.replace(f"<@{bot.user.id}>", "").replace(f"<@!{bot.user.id}>", "").strip()
        if clean_prompt:
            async with message.channel.typing():
                await process_llm_prompt(
                    channel_id=message.channel.id,
                    prompt=clean_prompt,
                    send_func=message.channel.send,
                    channel_obj=message.channel,
                    provider="gemini-fast",
                    guild_id=getattr(message.guild, "id", None),
                    author_id=message.author.id,
                    author_name=message.author.display_name,
                )
            return
    await bot.process_commands(message)


@bot.tree.command(name="ask", description="Ask FlowBot using crew memory and open task context")
@app_commands.describe(prompt="What would you like to ask FlowBot?")
async def ask_command(interaction: discord.Interaction, prompt: str):
    await interaction.response.defer(thinking=True)
    await process_llm_prompt(
        interaction.channel_id, prompt, interaction.followup.send, interaction.channel, "gemini-fast",
        getattr(interaction.guild, "id", None), interaction.user.id, interaction.user.display_name,
    )


@bot.tree.command(name="draft", description="Generate a detailed draft using FlowRoots context")
@app_commands.describe(prompt="What content or proposal do you want FlowBot to draft?")
async def draft_command(interaction: discord.Interaction, prompt: str):
    await interaction.response.defer(thinking=True)
    await process_llm_prompt(
        interaction.channel_id, prompt, interaction.followup.send, interaction.channel, "gemini-pro",
        getattr(interaction.guild, "id", None), interaction.user.id, interaction.user.display_name,
    )


@bot.tree.command(name="summarize", description="Summarize recent messages and optionally store key decisions")
@app_commands.describe(instructions="Optional instructions for the summary")
async def summarize_command(interaction: discord.Interaction, instructions: str = "Summarize recent discussions, decisions, and action items."):
    await interaction.response.defer(thinking=True)
    history_text = await get_channel_context(interaction.channel, limit=40)
    if not history_text:
        await interaction.followup.send("No recent user messages found in this channel.")
        return
    prompt = f"{instructions}\n\nRecent Discord history:\n{history_text}"
    await process_llm_prompt(
        interaction.channel_id, prompt, interaction.followup.send, interaction.channel, "gemini-fast",
        getattr(interaction.guild, "id", None), interaction.user.id, interaction.user.display_name,
    )


@bot.tree.command(name="remember", description="Store a durable FlowRoots fact or decision")
@app_commands.describe(note="What should FlowBot remember?", category="Optional category")
async def remember_command(interaction: discord.Interaction, note: str, category: str = "general"):
    memory_id = memories.remember(
        note, getattr(interaction.guild, "id", None), interaction.channel_id,
        category[:40], interaction.user.display_name,
    )
    await interaction.response.send_message(f"🧠 Saved memory #{memory_id}: {note}")


@bot.tree.command(name="recall", description="Search FlowBot's durable memory")
@app_commands.describe(query="What are you trying to remember?")
async def recall_command(interaction: discord.Interaction, query: str):
    rows = memories.search(query, getattr(interaction.guild, "id", None), interaction.channel_id, limit=10)
    if not rows:
        await interaction.response.send_message("I couldn't find a matching saved memory.")
        return
    text = "\n".join(f"**#{m['id']} · {m['category']}** — {m['content']}" for m in rows)
    await interaction.response.send_message(text[:1900])


@bot.tree.command(name="task", description="Create a tracked FlowRoots task")
@app_commands.describe(title="Task title", owner="Owner name", due="Due date/time (free text or ISO)", priority="low, normal, high, urgent")
async def task_command(interaction: discord.Interaction, title: str, owner: str | None = None,
                       due: str | None = None, priority: str = "normal"):
    task_id = tasks.create(
        title=title, owner=owner, due_at=due, priority=priority.lower(),
        guild_id=getattr(interaction.guild, "id", None), channel_id=interaction.channel_id,
        created_by=interaction.user.display_name,
    )
    await interaction.response.send_message(f"✅ Created task **#{task_id}** — {title}")


@bot.tree.command(name="tasks", description="List open FlowRoots tasks")
@app_commands.describe(owner="Optional owner filter")
async def tasks_command(interaction: discord.Interaction, owner: str | None = None):
    rows = tasks.list(getattr(interaction.guild, "id", None), interaction.channel_id, owner=owner, limit=25)
    if not rows:
        await interaction.response.send_message("No open tasks found for this channel.")
        return
    lines = []
    for t in rows:
        due = f" · due {t['due_at']}" if t["due_at"] else ""
        own = f" · {t['owner']}" if t["owner"] else " · unassigned"
        lines.append(f"**#{t['id']}** [{t['priority']}] {t['title']}{own}{due} · {t['status']}")
    await interaction.response.send_message("\n".join(lines)[:1900])


@bot.tree.command(name="done", description="Mark a FlowRoots task complete")
@app_commands.describe(task_id="Task number")
async def done_command(interaction: discord.Interaction, task_id: int):
    if tasks.update_status(task_id, "done"):
        await interaction.response.send_message(f"🏁 Task **#{task_id}** marked done.")
    else:
        await interaction.response.send_message(f"Task #{task_id} was not found.")


@bot.tree.command(name="clear", description="Clear recent conversational context for this thread/channel")
async def clear_command(interaction: discord.Interaction):
    memories.clear_channel_messages(interaction.channel_id)
    await interaction.response.send_message("🧹 Recent conversation context cleared. Durable memories and tasks were kept.")


@bot.tree.command(name="flowhelp", description="Display FlowBot commands")
async def flowhelp_command(interaction: discord.Interaction):
    text = (
        "**🌊 FlowBot**\n"
        "`/ask` ask with crew memory + task context\n"
        "`/draft` detailed writing\n"
        "`/summarize` summarize recent Discord discussion\n"
        "`/remember` save a durable fact/decision\n"
        "`/recall` search durable memory\n"
        "`/task` create a task\n"
        "`/tasks` list open tasks\n"
        "`/done` complete a task\n"
        "`/clear` clear recent chat context only\n"
        "You can also @FlowBot directly in any channel or thread."
    )
    await interaction.response.send_message(text)


@bot.command()
@commands.has_permissions(administrator=True)
async def sync(ctx):
    try:
        synced = await bot.tree.sync()
        await ctx.send(f"✅ Synced {len(synced)} global slash commands.")
    except Exception as exc:
        await ctx.send(f"❌ Sync failed: {exc}")


def main():
    if not TOKEN:
        raise RuntimeError("DISCORD_TOKEN is not set. Copy .env.example to .env and configure it.")
    bot.run(TOKEN)


if __name__ == "__main__":
    main()
