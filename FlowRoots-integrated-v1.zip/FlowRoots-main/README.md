<p align="center">
  <img src="assets/FLOWROOTS_LOGO.png" alt="FlowRoots Logo" width="300"/>
</p>

<!-- <p align="center">
  <a href="https://www.instagram.com/flowrootsdallas/">
    <img src="IG_PROFILE.png" alt="IG Profile" width="100"/>
  </a>
</p> -->

## 💡 Vision
### “To strengthen and connect the street dance community through accessible, ethical AI tools.”

### A passion project centered around a useful tool for the local Dallas dance community, specifically street styles.

### The idea and vision is to create a hub and AI assistant focused on helping dancers in Dallas find their path and get assistance and updates on happenings such as events, cyphers, classes, etc. It may be used as a Point of Contact Site for outside organizations looking to interact with this niche community.

# FlowRoots App 🎶💃

A Python-based AI and community-driven project for dancers in styles such as **Popping, Robot, Animation, Tutting, and Waving**.  
FlowRoots aims to help dancers **learn, discover events, connect with communities, and preserve dance culture** — all through accessible technology.

---

## 🌱 Current Phase
We’re building the project from the ground up with:
- A **command-line interface (CLI)** foundation
- Placeholder modules for *Learn*, *Discover*, *Contribute*, and *Chatbot*
- Emphasis on **ethical, community-centered AI**

---

## 🧩 Structure

```plaintext
FlowRoots_App/
├── main.py
├── modules/
├── chatbot/
├── data/
├── web/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── README.md
```


---

## 🚀 How to Run
1. Make sure you have Python 3.9+ installed  
2. Open a terminal in the project folder  
3. Run the app:
   ```bash
   python main.py

---

## ⚙️ Future Plans

* Integrate a real chatbot using LangChain or Transformers

* Add event scraping or API integration

* Build a lightweight web interface (Streamlit or Flask)

* Enable user submissions and local data persistence

## 🧠 Author

### Marc Anthony Aradillas
### FlowRoots Project | Dallas Dance Community

---

## FlowBot v1 — Integrated Operations Layer

FlowBot now combines Discord conversation, durable memory, task tracking, and safe natural-language actions.

### Core architecture

```text
Discord
  ↓
FlowBot handlers
  ↓
Gemini router + action planner
  ↓
SQLite operational store
  ├── messages
  ├── durable memories
  ├── tasks
  └── action log
  ↓
Optional service adapters
  ├── GitHub
  ├── Google Calendar
  └── Google Drive / documents
```

### Discord commands

- `/ask` — ask FlowBot with relevant memory and task context
- `/draft` — use the heavier model route for detailed writing
- `/summarize` — summarize recent Discord discussion
- `/remember` — save a durable fact or decision
- `/recall` — search durable memory
- `/task` — create a tracked task
- `/tasks` — list open tasks
- `/done` — complete a task
- `/clear` — clear recent chat context while keeping durable memory/tasks
- `@FlowBot ...` — natural-language conversation with automatic context retrieval

### Setup

1. Create a virtual environment.
2. Install dependencies: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`.
4. Add `DISCORD_TOKEN` and `GEMINI_API_KEY`.
5. Run from the repository root: `python -m chatbot.flow_bot`
6. In Discord, run `!sync` once from an administrator account to register slash commands.

SQLite data is stored at `data/flowbot.db` by default and is intentionally ignored by Git.

### Safe action model

Natural-language action planning is constrained to local, reversible operational data:

- save a durable memory
- create a task
- complete a task

GitHub, Calendar, and document integrations live behind service boundaries in `chatbot/services/`. They are intentionally not granted implicit write access until credentials and concrete permission rules are configured.

### Tests

Run: `python -m unittest discover -s tests -v`
